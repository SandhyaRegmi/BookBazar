﻿using BookStoreMVc.Models;
using Microsoft.EntityFrameworkCore;

namespace BookStoreMVc.Services
{
    public class OrderService
    {
        private readonly AppDbContext _context;
        private readonly IEmailService _emailService;

        public OrderService(AppDbContext context, IEmailService emailService)
        {
            _context = context;
            _emailService = emailService;
        }

        public async Task<Order> PlaceOrderAsync(int memberId, List<(int bookId, int quantity)> items)
        {
            var member = await _context.Members.FindAsync(memberId);
            if (member == null) throw new Exception("Member not found");

            var order = new Order
            {
                MemberId = memberId,
                OrderDate = DateTime.UtcNow,
                ClaimCode = Guid.NewGuid().ToString().Substring(0, 8).ToUpper(),
                IsCompleted = false,
                OrderItems = new List<OrderItem>()
            };

            decimal total = 0;
            int totalBooks = 0;

            foreach (var (bookId, quantity) in items)
            {
                var book = await _context.Books.FindAsync(bookId);
                if (book == null || book.Stock < quantity) throw new Exception("Book unavailable");

                total += book.Price * quantity;
                totalBooks += quantity;

                order.OrderItems.Add(new OrderItem
                {
                    BookId = bookId,
                    Quantity = quantity,
                    Price = book.Price
                });

                book.Stock -= quantity;
            }

            // Apply 5% discount if total books >= 5
            if (totalBooks >= 5)
                total *= 0.95m;

            bool loyaltyDiscountApplied = false;

            // Apply 10% loyalty discount if member has completed 10 successful orders
            if (member.SuccessfulOrders == 10)
            {
                total *= 0.90m;
                loyaltyDiscountApplied = true;
                member.SuccessfulOrders = 0; // reset
            }

            order.TotalPrice = total;
            _context.Orders.Add(order);
            await _context.SaveChangesAsync();

            // Build HTML Bill
            string billHtml = $@"
<html>
<body style='font-family: Arial, sans-serif;'>
    <h2 style='color: #2c3e50;'>Order Confirmation</h2>
    <p>Thank you for your purchase, <strong>{member.Name}</strong>!</p>
    <p><strong>Claim Code:</strong> <span style='color: #27ae60;'>{order.ClaimCode}</span></p>
    <p><strong>Order Date:</strong> {order.OrderDate:yyyy-MM-dd HH:mm}</p>";

            if (loyaltyDiscountApplied)
            {
                billHtml += "<p style='color:green'><strong>Congratulations!</strong> You received a 10% loyalty discount for completing 10 previous orders!</p>";
            }

            billHtml += @"
    <h3>Order Summary</h3>
    <table style='border-collapse: collapse; width: 100%;'>
        <thead>
            <tr style='background-color: #f2f2f2;'>
                <th style='border: 1px solid #ddd; padding: 8px;'>Book</th>
                <th style='border: 1px solid #ddd; padding: 8px;'>Quantity</th>
                <th style='border: 1px solid #ddd; padding: 8px;'>Price/Book</th>
                <th style='border: 1px solid #ddd; padding: 8px;'>Total</th>
            </tr>
        </thead>
        <tbody>";

            foreach (var item in order.OrderItems)
            {
                var book = await _context.Books.FindAsync(item.BookId);
                billHtml += $@"
            <tr>
                <td style='border: 1px solid #ddd; padding: 8px;'>{book?.Title ?? "Unknown"}</td>
                <td style='border: 1px solid #ddd; padding: 8px;'>{item.Quantity}</td>
                <td style='border: 1px solid #ddd; padding: 8px;'>${item.Price}</td>
                <td style='border: 1px solid #ddd; padding: 8px;'>${item.Price * item.Quantity}</td>
            </tr>";
            }

            billHtml += $@"
        </tbody>
    </table>
    <h3 style='text-align: right; margin-top: 20px;'>Total Amount: ${order.TotalPrice}</h3>
    <p>If you have any questions, feel free to contact our support.</p>
    <p>Best regards,<br><strong>The Book Store Team</strong></p>
</body>
</html>";

            await _emailService.SendEmailAsync(member.Email, "Your Order Confirmation & Claim Code", billHtml);
            return order;
        }


        public async Task<bool> CompleteOrderAsync(string claimCode)
        {
            var order = await _context.Orders
                .Include(o => o.Member)
                .FirstOrDefaultAsync(o => o.ClaimCode == claimCode && !o.IsCompleted);

            if (order == null)
                return false;

            order.IsCompleted = true;

            // Increment successful orders for the member
            var member = order.Member;
            if (member != null)
            {
                member.SuccessfulOrders++;

                // Apply 10% stackable discount logic: reset if already >=10
                if (member.SuccessfulOrders >= 10)
                {
                    member.SuccessfulOrders = 0;
                }
            }

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<List<Order>> GetIncompleteOrdersAsync()
        {
            return await _context.Orders
                .Where(o => !o.IsCompleted)
                .Include(o => o.Member)
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.Book)
                .ToListAsync();
        }
        public async Task<Order?> GetOrderByIdAsync(int id)
        {
            return await _context.Orders
                .Include(o => o.Member)
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.Book)
                .FirstOrDefaultAsync(o => o.Id == id);
        }

    }
}
