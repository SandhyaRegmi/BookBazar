using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BookStoreMVc.Views.Order
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
