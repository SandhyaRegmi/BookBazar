using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BookStoreMVc.Views.Order
{
    public class ConfirmationModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
