﻿using Microsoft.AspNetCore.Mvc;
using BookStoreMVc.Services;
using System.Threading.Tasks;

namespace BookStoreMVc.Controllers
{
    public class StaffController : Controller
    {
        private readonly OrderService _orderService;

        public StaffController(OrderService orderService)
        {
            _orderService = orderService;
        }

        [HttpGet]
        public async Task<IActionResult> CompleteOrder()
        {
            var orders = await _orderService.GetIncompleteOrdersAsync();
            return View(orders);
        }

     
        [HttpPost]
        public async Task<IActionResult> ConfirmOrder(int orderId, string claimCode)
        {
            if (string.IsNullOrWhiteSpace(claimCode))
            {
                ViewBag.Message = "Claim code is required.";
                var orders = await _orderService.GetIncompleteOrdersAsync();
                return View("CompleteOrder", orders);
            }

            var order = await _orderService.GetOrderByIdAsync(orderId);
            if (order == null || order.IsCompleted)
            {
                ViewBag.Message = "Invalid or already completed order.";
                var orders = await _orderService.GetIncompleteOrdersAsync();
                return View("CompleteOrder", orders);
            }

            if (!string.Equals(order.ClaimCode, claimCode.Trim(), StringComparison.OrdinalIgnoreCase))
            {
                ViewBag.Message = "Incorrect claim code.";
                var orders = await _orderService.GetIncompleteOrdersAsync();
                return View("CompleteOrder", orders);
            }

            await _orderService.CompleteOrderAsync(order.ClaimCode);
            ViewBag.Message = "Order successfully confirmed!";
            var updatedOrders = await _orderService.GetIncompleteOrdersAsync();
            return View("CompleteOrder", updatedOrders);
        }

    }
}
