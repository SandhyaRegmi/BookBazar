﻿using BookStoreMVc.Models;
using BookStoreMVc.Services;
using Microsoft.AspNetCore.Mvc;

using Microsoft.EntityFrameworkCore;
namespace BookStoreMVc.Controllers
{
    public class OrderController : Controller
    {
        private readonly AppDbContext _context;
        private readonly OrderService _orderService;

        public OrderController(AppDbContext context, OrderService orderService)
        {
            _context = context;
            _orderService = orderService;
        }

        // Show books to order
        public async Task<IActionResult> Create()
        {
            var books = await _context.Books.ToListAsync();
            return View(books);
        }
        private int GetLoggedInMemberId()
        {
            // var userIdClaim = User.Claims.FirstOrDefault(c => c.Type == "MemberId");
            // if (userIdClaim == null)
            // {
            //     throw new Exception("User not logged in or MemberId claim not found.");
            // }

            // return int.Parse(userIdClaim.Value);

            return 1; // Temporary until login is implemented
        }

        // Submit order
        [HttpPost]
        public async Task<IActionResult> Create(List<int> bookIds, List<int> quantities)
        {
            var memberId = GetLoggedInMemberId();
           

            var items = new List<(int, int)>();
            for (int i = 0; i < bookIds.Count; i++)
            {
                if (quantities[i] > 0)
                    items.Add((bookIds[i], quantities[i]));
            }

            var order = await _orderService.PlaceOrderAsync(memberId, items);
            return RedirectToAction("Confirmation", new { id = order.Id });
        }

        public async Task<IActionResult> Confirmation(int id)
        {
            var order = await _context.Orders
                .Include(o => o.Member)
                .FirstOrDefaultAsync(o => o.Id == id);

            return View(order);
        }
    }
}
