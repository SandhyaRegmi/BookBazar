﻿using BookStoreMVc.Models;
using Microsoft.AspNetCore.Mvc;

namespace BookStoreMVc.Controllers
{
    public class BookController : Controller
    {
        private readonly AppDbContext _context;

        public BookController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Book/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Book/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Book book)
        {
            // Just for debugging
            _context.Books.Add(book);
            _context.SaveChanges();

            return RedirectToAction("Create");
        }


        // Optionally: list all books
        public IActionResult List()
        {
            var books = _context.Books.ToList();
            return View(books);
        }
    }
}
