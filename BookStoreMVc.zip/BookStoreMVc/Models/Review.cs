﻿namespace BookStoreMVc.Models
{
    public class Review
    {
        public int Id { get; set; }
        public int Rating { get; set; }  // Rating given by the member (1 to 5 stars)
        public string Comment { get; set; }  // Optional comment for the review
        public DateTime CreatedAt { get; set; } // Date when the review was created
        public int MemberId { get; set; }  // Foreign Key to Member
        public Member Member { get; set; }  // Navigation property to Member
        public int BookId { get; set; }  // Foreign Key to Book
        public Book Book { get; set; }  // Navigation property to Book
    }

}
