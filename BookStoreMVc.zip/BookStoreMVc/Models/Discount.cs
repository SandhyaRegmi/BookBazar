﻿namespace BookStoreMVc.Models
{
    public class Discount
    {
        public int Id { get; set; }
        public decimal Percentage { get; set; }  // Discount percentage
        public string Description { get; set; }  // Description of the discount
        public DateTime StartDate { get; set; }  // Start date for the discount
        public DateTime EndDate { get; set; }  // End date for the discount
        public int BookId { get; set; }  // Foreign Key to Book (for book-specific discounts)
        public Book Book { get; set; }  // Navigation property to Book
    }

}
