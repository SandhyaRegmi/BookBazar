﻿namespace BookStoreMVc.Models
{
    public class Member
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public int SuccessfulOrders { get; set; }  // Keeps track of the number of successful orders
        public string? MembershipId { get; set; }  // Unique Membership ID for the member
        public ICollection<Order> Orders { get; set; }  // A member can have multiple orders

        // Calculated property for discount eligibility
        public bool IsEligibleForStackableDiscount => SuccessfulOrders >= 10;
    }

}
