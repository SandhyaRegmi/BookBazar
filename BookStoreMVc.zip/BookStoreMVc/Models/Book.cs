﻿namespace BookStoreMVc.Models
{
    public class Book
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string? Author { get; set; }
        public decimal Price { get; set; }
        public string? Genre { get; set; }
        public bool? IsAvailable { get; set; }  // Availability status
        public string? Format { get; set; }  // e.g., Paperback, Hardcover, Signed Edition
        public double? Rating { get; set; }  // Rating for the book
        public string? Language { get; set; }  // Language of the book
        public DateTime? PublishedDate { get; set; }  // Publication date
        public int Stock { get; set; }
        public ICollection<OrderItem> OrderItems { get; set; }  // A book can appear in multiple orders
    }

}
