﻿namespace BookStoreMVc.Models
{
    public class OrderItem
    {
        public int Id { get; set; }
        public int Quantity { get; set; }  // Quantity of the book in this order
        public decimal Price { get; set; }  // Price of the book at the time of the order
        public int OrderId { get; set; }  // Foreign Key to Order
        public Order Order { get; set; }  // Navigation property to Order
        public int BookId { get; set; }  // Foreign Key to Book
        public Book Book { get; set; }  // Navigation property to Book
    }

}
