﻿namespace BookStoreMVc.Models
{
    public class Order
    {
        public int Id { get; set; }
        public DateTime OrderDate { get; set; }
        public decimal TotalPrice { get; set; }  // Total price for the order
        public string ClaimCode { get; set; }  // Unique claim code for the order
        public bool IsCompleted { get; set; }  // Order fulfillment status
        public int MemberId { get; set; }  // Foreign Key to Member
        public Member Member { get; set; }  // Navigation property to Member
        public ICollection<OrderItem> OrderItems { get; set; }  // List of books in the order
    }

}
